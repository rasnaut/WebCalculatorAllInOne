package com.example.j_calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
